
import Navbar from './components/navbar/Navbar'

function App() {


  return (
    <>
      <Navbar />
    </>
  )
}

export default App
