// Portfoliodata
//images
import Img1 from '../../assets/portfolio/img1.png'
import Img2 from '../../assets/portfolio/img2.png'
const portfoliodata = [
  {
    id: "01",
    title: "Interior design",
    description:"Hello Welcome to my World",
    button:"Get This Design",
    images: [
      Img1,Img2,
    ],
    related: [
      Img1,Img2,
      Img1,Img2,
    ],
    speed: 12,
  },

  {
    id: "02",
    title: "wooden interior",
    description:"Hello Welcome to my World",
    button:"Get This Design",
    images: [
      Img1,Img2,
    ],
    related: [
      Img1,Img2,
      Img1,Img2,
    ],
    speed: 16,
  },
  {
    id: "03",
    title: "carpet interior",
    description:"Hello Welcome to my World",
    button:"Get This Design",
    images: [
      Img1,Img2,
    ],
    related: [
      Img1,Img2,
      Img1,Img2,
    ],
    speed: 16,
  },
  {
    id: "04",
    title: "carpet interior",
    description:"Hello Welcome to my World",
    button:"Get This Design",
    images: [
      Img1,Img2,
      Img1,Img2,
      Img1,Img2,
    ],
    related: [
      Img1,Img2,
      Img1,Img2,
    ],
    speed: 16,
  },
  {
    id: "05",
    title: "carpet interior",
    description:"Hello Welcome to my World",
    button:"Get This Design",
    images: [
      Img1,Img2,
      Img1,Img2,
    ],
    related: [
      Img1,Img2,
      Img1,Img2,
    ],
    speed: 16,
  },
  {
    id: "06",
    title: "carpet interior",
    description:"Hello Welcome to my World",
    button:"Get This Design",
    images: [
      Img1,Img2,
      Img1,Img2,
    ],
    related: [
      Img1,Img2,
      Img1,Img2,
    ],
    speed: 16,
  },
  {
    id: "07",
    title: "carpet interior",
    description:"Hello Welcome to my World",
    button:"Get This Design",
    images: [
      Img1,Img2,
      Img1,Img2,
    ],
    related: [
      Img1,Img2,
      Img1,Img2,
    ],
    speed: 16,
  },
  {
    id: "08",
    title: "carpet interior",
    description:"Hello Welcome to my World",
    button:"Get This Design",
    images: [
      Img1,Img2,
      Img1,Img2,
    ],
    related: [
      Img1,Img2,
      Img1,Img2,
    ],
    speed: 16,
  },
  {
    id: "09",
    title: "carpet interior",
    description:"Hello Welcome to my World",
    button:"Get This Design",
    images: [
      Img1,Img2,
      Img1,Img2,
    ],
    related: [
      Img1,Img2,
      Img1,Img2,
    ],
    speed: 16,
  },
];

export default portfoliodata;
