import react from 'react';
import Pricetoday from '../../../assets/Price_img/price-today.png'
import '../pricetoday/PriceToday.css';
export default function PriceToday() {
  return (
    <>
        <section className='Pice-today_sect' >  
           <div className='Price-background'>
                <h2>Get Your Interior Design Price Today</h2>
                <p>Access easy, transparent pricing for modular kitchen, wardrobe and home interiors. Get accurate cost guidance and customized options for Pondicherry & Cuddalore.</p>
                <button>Start My Interior Plan</button>
           </div>
           <div className='Price-today-img'>
                <img src={Pricetoday} alt="" />
           </div>
        </section>
    </>
  )
}